import pyodbc

"""Database connector til my SQL. Brukes til å lagre relevante datapoints"""
conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=root;'
                      'Database=Bachelor;'
                      'Trusted_Connection=yes;')

cursor = conn.cursor()
cursor.execute('SELECT * FROM Bachelor.test')

"""Parse SQL query into database. en linje av gangen """
for row in cursor:
    print(row)

cursor.execute('insert into Bachelor.test values all')

import gzip

from k_means import KMeans
import glob

import flask
from flask import Flask, jsonify, request, make_response

import sys
import pandas as pd
import matplotlib.pyplot as plt


""""Åpner alle filer med en for loop og legger det i et Array"""
path = r'C:/Zero North'
all_files = glob.glob(path + "/*.ais")

li = []
"""Gziped er komprimert format på dataen"""
for filename in all_files:
    df = gzip.open(filename, mode='rt', compresslevel=9, encoding=None, errors=None)
    li.append(df.read())
    frame = pd.array(li)
    df2 = pd.DataFrame(frame)
    df.close()
"""Split datafram til et trenings og testsett"""
train=df2.sample(frac=0.8, random_state=200) #random state er en seed value, 80% er train
test=df2.drop(train.index) #20% er testset

"""Long lat blir satt som verdier"""
X = train[['Long (k$)', 'Lat (1-100)']]

plt.style.use('mmsi')
plt.scatter(X['Long (k$)'], X['Lat (1-100)'])
plt.xlabel('Long (k$)')
plt.ylabel('Lat (k$)')

"""Antall clusters blir basert på antall skip som er 46 893, det blir kjør 100 iterasjoner som tar ca
90 timer å kjøre avhengig av maskinkraft"""
model = KMeans(max_iter = 500, tolerance = 0.001, n_clusters = 46893, runs = 100)
(train, data_with_clusters) = model.fit(X)


"""Test av plotting"""
plt.close()
for i, cluster_mean in enumerate(train):
    data_cluster_i = data_with_clusters[ data_with_clusters[:, -1] == i ]
    plt.scatter(data_cluster_i[:, 0], data_cluster_i[:, 1], label = 'Cluster ' + str(i))
    plt.plot(cluster_mean[0], cluster_mean[1], label = 'mmsi center ' + str(i), marker='*', markersize=15, markeredgecolor="k", markeredgewidth=1)
    plt.xlabel('Long (k$)')
    plt.ylabel('Lat (1-100)')
    plt.style.use('mmsi')
    plt.legend()

"""Forsøk på å bruke albue metode for å finne optimalt antall clusters"""
def elbow_method(X, max_k=10):
        clusters = []
        for k in range(2, max_k):
            model = KMeans(n_clusters=k, init_method='var_part')
            model.fit(X)
            clusters.append(model.cost_)
        plt.close()
        plt.plot(list(range(2, max_k)), clusters)
        plt.xlabel("# of clusters (K)")
        plt.ylabel("Cost")
        elbow_method(X)

"""Dijkastras algoritme blir lagt ovenpå"""

class Graph():

    def __init__(self, vertices):
        self.V = vertices
        self.graph = [[0 for column in range(vertices)]
                      for row in range(vertices)]
    """Presenterer løsning"""
    def printSolution(self, dist):
        print
        "Vertex \tDistance from Source"
        for node in range(self.V):
            print
            node, "\t", dist[node]

    """funksjon for å finne minste avstand"""
    def minDistance(self, dist, sptSet):

        """Stjeler korteste avstans fra hver cluster"""
        min = sys.maxint

        """Finner minimal avstand"""
        for v in range(self.V):
            if dist[v] < min and sptSet[v] == False:
                min = dist[v]
                min_index = v

        return min_index

    """Utregning med korteste rute etter clustering"""
    def dijkstra(self, src):

        dist = [sys.maxint] * self.V
        dist[src] = 0
        sptSet = [False] * self.V

        for cout in range(self.V):


            u = self.minDistance(dist, sptSet)


            sptSet[u] = True


            for v in range(self.V):
                if self.graph[u][v] > 0 and sptSet[v] == False and \
                        dist[v] > dist[u] + self.graph[u][v]:
                    dist[v] = dist[u] + self.graph[u][v]
        """Printer løsning"""
        self.printSolution(dist)



"""Returnerer dataen fra modellen til front end"""
app = flask.Flask(__name__)
app.config["DEBUG"] = True
app.config['JSON_SORT_KEYS'] = False


# Unprotected function
@app.route('/Shipping_Route_Data')
def unprotected():
    return jsonify(model)


app.run()

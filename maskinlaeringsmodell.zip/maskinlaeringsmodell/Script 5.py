import gzip


fp = gzip.open(filename="C:/Zero North/1/10/1547078100_1547078400.ais", mode='rt',
                    compresslevel=9, encoding=None, errors=None)


print(fp.read())

fp.close()



from tableauhyperapi import HyperProcess, Connection, TableDefinition, SqlType, Telemetry, Inserter, CreateMode



# Start a new private local Hyper instance
with HyperProcess(Telemetry.SEND_USAGE_DATA_TO_TABLEAU, 'myapp') as hyper:
    # Create the extract, replace it if it already exists
    with Connection(hyper.endpoint, 'mydb.hyper', CreateMode.CREATE_AND_REPLACE) as connection:
        schema = TableDefinition('foo', [
            TableDefinition.Column('a', SqlType.text()),
            TableDefinition.Column('b', SqlType.big_int()),
        ])
        connection.catalog.create_table(schema)
        with Inserter(connection, schema) as inserter:
            inserter.add_rows([
                ['x', 1],
                ['y', 2],
            ])
            inserter.execute()



with Connection(hyper.endpoint, 'mydb.hyper') as connection:
    with Inserter(connection, 'foo') as inserter:
        inserter.add_row(['z', 3])
        inserter.execute()

with connection.execute_query('SELECT * FROM foo') as result:
    rows = list(result)
    assert sorted(rows) == [['x', 1], ['y', 2], ['z', 3]]

    top_a = connection.execute_scalar_query('SELECT MAX(b) FROM foo')
    assert top_a == 3

    connection.execute_command('DROP TABLE foo')
import pyodbc

"""Database connector to my SQL. Used to store data relevant datapoints"""
conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=root;'
                      'Database=Bachelor;'
                      'Trusted_Connection=yes;')

cursor = conn.cursor()
cursor.execute('SELECT * FROM Bachelor.test')

"""Parse SQL query into database. One line at the time """
for row in cursor:
    print(row)


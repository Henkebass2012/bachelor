import gzip
import shutil
from urllib import request

import io

import glob
import pandas as pd

#get data file names

path = r'C:\Zero North\1\10'
all_files = glob.glob(path + "/*.ais")

li = []

for filename in all_files:
    df = gzip.open(filename, mode='rt', compresslevel=9, encoding=None, errors=None)
    li.append(df.read())
    frame = pd.array(li)

    df2 = pd.DataFrame(frame, columns=['mmsi'])
print(df2)
df.close()




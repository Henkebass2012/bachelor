import gzip
import io
import json
import pandas as pd
from tornado.escape import to_unicode
import numpy as np
from json import JSONDecoder
from pandas.io.json import __all__

"""Decoompress gziped file. Compression level 9 means highest level on scale"""
fp = gzip.open(filename="C:/Zero North/1/10/1547078100_1547078400.ais", mode='rt',
                    compresslevel=9, encoding="utf-8", errors=None)

"""Open as data frame to seperate objects"""
with open("C:/Zero North/1/10/1547078100_1547078400.ais", 'rb') as fd:
    gzip_fd = gzip.GzipFile(fileobj=fd)
    ais = pd.read_json(gzip_fd)

    """Extract collectioen type data from data set"""
    df2 = pd.DataFrame(ais, columns=["mmsi"])
    """df2.to_csv('C:/Users/Bruker/Documents/6. Semester/Bachelorprosjekt/00 PROGGING INKL ZN/mmsi.csv')"""


    df3 = pd.DataFrame(ais, columns=["collection_type"])
    """Extract collectioen type data from data set"""
    df3.to_csv('C:/Users/Bruker/Documents/6. Semester/Bachelorprosjekt/00 PROGGING INKL ZN/collectiontype.csv')

    print(df3)



fp.close()





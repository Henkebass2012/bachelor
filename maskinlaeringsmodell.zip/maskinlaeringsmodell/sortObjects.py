import csv
import gzip
import io
import json
import sys
import os


from numpy.distutils.fcompiler import none
from tornado.escape import to_unicode




class AIS:
    def__init__(links, vessel, id, mmsi, vessel_id, timestamp, created_at, geometry, heading, speed, rot, collection_type, maneuver, course):
    links.vessel = vessel
    links.id = id
    links.vessel_id = vessel_id
    links.mmsi = mmsi
    links.timestamp = timestamp
    links.created_at = created_at
    links.geometry=geometry
    links.heading = heading
    links.speed = speed
    links.rot = rot
    links.collection_type = collection_type
    links.maneuver = maneuver
    links.course = course

    links.ais = []

fp = gzip.open(filename="C:/Zero North/1/10/1547078100_1547078400.ais", mode='rt',
               compresslevel=9, newline='', encoding=None, errors=None)
print(fp.read())
"""io.TextIOBase(buffer=raw, encoding=None, errors=None, newline= '\n', line_buffering=False, write_through=False)"""



deck = []
for line in fp:
    row = line.split('{"')
    card_id, name, desc, hp = [i.strip() for i in row]
    ais = AIS(links, vessel, id, mmsi, vessel_id)
    deck = deck + [ card ]




